
# Import new service object
from pywfs.service import Service
# When loaded it is assumed that the directory is above

if __name__ == "__main__":
    pass
