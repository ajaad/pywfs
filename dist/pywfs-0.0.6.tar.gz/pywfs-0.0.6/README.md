# pywfs
Web Feature Service (WFS) in Python3
Intended for use on servers that only supports python3 scripts.

## Objects

# Service
The service object creates a wfs-service.

## Build .whl-file

```bash
$ python3 -m build
```

by Anders Johan Konnestad
